# Hertz-Partnerportal – echte Version mit Supabase + Vercel

## 1. Supabase einrichten
1. Auf https://supabase.com ein neues Projekt erstellen.
2. In Supabase links auf **SQL Editor** gehen.
3. Inhalt aus `supabase/schema.sql` einfügen und ausführen.
4. Unter **Authentication > Providers > Email** E-Mail-Login aktiv lassen.
5. Unter **Project Settings > API** `Project URL` und `anon public key` kopieren.

## 2. Lokal starten
```bash
npm install
cp .env.example .env
# .env mit Supabase URL und anon key füllen
npm run dev
```

## 3. Bei Vercel veröffentlichen
1. Projektordner zu GitHub hochladen.
2. In Vercel neues Projekt importieren.
3. Environment Variables setzen:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
4. Deploy klicken.

## 4. Admin-Rechte
In Supabase nach der Registrierung in Tabelle `profiles` beim gewünschten Nutzer `role = admin` setzen.
